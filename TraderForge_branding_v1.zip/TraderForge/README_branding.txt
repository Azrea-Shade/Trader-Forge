Trader Forge – Branding Pack v1
--------------------------------
Files:
- trader_forge_logo_1024.png : Master logo
- icon_[size].png            : PNG app icons (512..16)
- trader_forge.ico           : Windows multi-size icon (256,128,64,48,32,16)
- banner_1600x400.png        : Wide banner (README / GitHub)
- splash_1280x640.png        : Splash / installer art
- WizardImage_164x314.bmp    : Inno Setup wizard image
- WizardSmallImage_55x58.bmp : Inno Setup small wizard image
- colors.json                : Brand color references

Suggested Usage (Windows C#):
- Set ApplicationIcon to assets/branding/TraderForge/trader_forge.ico in your .csproj
- Use banner for repo README header and splash for installer background
- Keep PNG icons for app shortcuts, docs, and marketing

Color Palette:
- Background: #0b0f1a
- Cyan Glow:  #00e1ff
- Magenta Glow: #ff4dff
- Purple Accent: #a64dff
- Steel: #c7d0d8